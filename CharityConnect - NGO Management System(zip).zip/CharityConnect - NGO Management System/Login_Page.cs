﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_Basic
{
    public partial class Login_Page : Form
    {
        public Login_Page()
        {
            InitializeComponent();
            textBox2.PasswordChar = '*';
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            int attempts;
            if (!int.TryParse(lblAttemptCounter.Text, out attempts))
            {
                attempts = 0; 
            }
            string n =textBox1.Text;
            string p =textBox2.Text;
            if(n=="kashish" && p == "sharma")
            {
                progressBar1.Visible = true; 
                progressBar1.Value = 0;

                for (int i = 0; i <= 100; i += 20)
                {
                    progressBar1.Value = i;
                    await Task.Delay(300); 
                }
                MessageBox.Show("Login Success");
                Main m = new Main(n);
                this.Hide();
                m.Show();
            }
            else
            {
                attempts++; 
                lblAttemptCounter.Text = attempts.ToString();

                lblErrorMessage.Text = $"Incorrect! Attempts left: {3 - attempts}";
                lblErrorMessage.Visible = true;

                if (attempts >= 3)
                {
                    button1.Enabled = false; 
                    lblErrorMessage.Text = "Too many failed attempts. Try again later.";
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide(); 
            Registration_Page regPage = new Registration_Page();
            regPage.ShowDialog(); 
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShowPassword.Checked)
            {
                textBox2.PasswordChar = '\0'; 
            }
            else
            {
                textBox2.PasswordChar = '*';
            }
        }
    }
}
