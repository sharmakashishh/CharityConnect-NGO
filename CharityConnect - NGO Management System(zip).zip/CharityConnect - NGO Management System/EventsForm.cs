﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_Basic
{
    public partial class EventsForm: Form
    {
        private readonly string connectionString = ("Data Source=KASHISH\\SQLEXPRESS01;Initial Catalog=ngo;Integrated Security=True;Encrypt=False");
        public EventsForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void EventsForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'ngoDataSet1.Events' table. You can move, or remove it, as needed.
            // this.eventsTableAdapter.Fill(this.ngoDataSet1.Events);
            LoadEvents();

        }
        private void LoadEvents(string searchQuery = "")
        {
            dataGridView1.Columns.Clear();
            dataGridView1.DataSource = null;  
            dataGridView1.AutoGenerateColumns = true;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT EventID, Title, Organizer, Description, EventDate, Location FROM Events";

                if (!string.IsNullOrEmpty(searchQuery))
                {
                    query += " WHERE Title LIKE @Search OR Organizer LIKE @Search OR Location LIKE @Search";
                }

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Search", "%" + searchQuery + "%");

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView1.DataSource = dt;

                }
            }
        }

        private void ClearTextBoxes()
        {
            txtTitle.Clear();
            txtOrganizer.Clear();
            txtDescription.Clear();
            txtLocation.Clear();
            dtpEventDate.Value = DateTime.Now; // Reset date picker to current date
        }

        private bool IsFormValid()
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text) ||
                string.IsNullOrWhiteSpace(txtOrganizer.Text) ||
                string.IsNullOrWhiteSpace(txtDescription.Text) ||
                string.IsNullOrWhiteSpace(txtLocation.Text)) 
            {
                MessageBox.Show("Please fill in all fields before submitting.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;

        }
        
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!IsFormValid()) return;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO Events (Title, Organizer, Description, EventDate, Location) VALUES (@Title, @Organizer, @Description, @EventDate, @Location)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Title", txtTitle.Text);
                    cmd.Parameters.AddWithValue("@Organizer", txtOrganizer.Text);
                    cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                    cmd.Parameters.AddWithValue("@EventDate", dtpEventDate.Value);
                    cmd.Parameters.AddWithValue("@Location", txtLocation.Text);
                    cmd.ExecuteNonQuery();
                }
            }
            MessageBox.Show("Event Added Successfully!");
            ClearTextBoxes();
            LoadEvents();  
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an event to edit.");
                return;
            }
            if (!IsFormValid()) return;

            int eventID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["EventID"].Value);

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "UPDATE Events SET Title = @Title, Organizer = @Organizer, Description = @Description, EventDate = @EventDate WHERE EventID = @EventID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Title", txtTitle.Text);
                    cmd.Parameters.AddWithValue("@Organizer", txtOrganizer.Text);
                    cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                    cmd.Parameters.AddWithValue("@EventDate", dtpEventDate.Value);
                    cmd.Parameters.AddWithValue("@EventID", eventID);
                    cmd.Parameters.AddWithValue("@Location", txtLocation.Text);
                    cmd.ExecuteNonQuery();
                }
            }
            MessageBox.Show("Event Updated Successfully!");
            ClearTextBoxes();
            LoadEvents();  // Refresh DataGridView

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an event to delete.");
                return;
            }
            DialogResult result = MessageBox.Show("Are you sure you want to delete this event?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.No)
            {
                return;
            }

            int eventID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["EventID"].Value);

            using (SqlConnection conn = new SqlConnection("Data Source=KASHISH\\SQLEXPRESS01;Initial Catalog=ngo;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();
                string query = "DELETE FROM Events WHERE EventID = @EventID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EventID", eventID);
                    cmd.ExecuteNonQuery();
                }
            }
            MessageBox.Show("Event Deleted Successfully!");
            ClearTextBoxes();
            LoadEvents();  // Refresh DataGridView
        }

        private void btnAddToGoogleCalendar_Click(object sender, EventArgs e)
        {

            // Check if an event is selected
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an event to add to Google Calendar.", "No Event Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Retrieve event details from the selected row
            string title = dataGridView1.SelectedRows[0].Cells["Title"].Value.ToString();
            string description = dataGridView1.SelectedRows[0].Cells["Description"].Value.ToString();
            string organizer = dataGridView1.SelectedRows[0].Cells["Organizer"].Value.ToString();
            DateTime eventDate = Convert.ToDateTime(dataGridView1.SelectedRows[0].Cells["EventDate"].Value);

            // Format event date for Google Calendar (RFC3339 format)
            string startDate = eventDate.ToString("yyyyMMddTHHmmssZ");
            string endDate = eventDate.AddHours(2).ToString("yyyyMMddTHHmmssZ"); // Assuming event lasts 2 hours

            // Generate Google Calendar Event URL
            string googleCalendarUrl = $"https://www.google.com/calendar/render?action=TEMPLATE" +
                                       $"&text={Uri.EscapeDataString(title)}" +
                                       $"&details={Uri.EscapeDataString(description)}" +
                                       $"&location={Uri.EscapeDataString(organizer)}" +
                                       $"&dates={startDate}/{endDate}";

            // Open Google Calendar event link in the default web browser
            Process.Start(new ProcessStartInfo { FileName = googleCalendarUrl, UseShellExecute = true });


        }

        private void btnShowMap_Click(object sender, EventArgs e)
        {
            string location = txtLocation.Text;
            if (!string.IsNullOrEmpty(location))
            {
                string mapsUrl = "https://www.google.com/maps/search/?api=1&query=" + Uri.EscapeDataString(location);
                System.Diagnostics.Process.Start(mapsUrl);
            }
            else
            {
                MessageBox.Show("Please enter a location.");
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                txtTitle.Text = dataGridView1.SelectedRows[0].Cells["Title"].Value.ToString();
                txtOrganizer.Text = dataGridView1.SelectedRows[0].Cells["Organizer"].Value.ToString();
                txtDescription.Text = dataGridView1.SelectedRows[0].Cells["Description"].Value.ToString();
                txtLocation.Text = dataGridView1.SelectedRows[0].Cells["Location"].Value.ToString();
                dtpEventDate.Value = Convert.ToDateTime(dataGridView1.SelectedRows[0].Cells["EventDate"].Value);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchText = txtSearch.Text.Trim();
            LoadEvents(searchText);
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch.PerformClick();
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Ensure the row index is valid
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Populate the textboxes with the selected row's data
                txtTitle.Text = row.Cells["Title"].Value?.ToString();
                txtOrganizer.Text = row.Cells["Organizer"].Value?.ToString();
                txtDescription.Text = row.Cells["Description"].Value?.ToString();
                dtpEventDate.Value = Convert.ToDateTime(row.Cells["EventDate"].Value);
                txtLocation.Text = row.Cells["Location"].Value?.ToString();
            }
        }
    }
}
