﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_Basic
{
    public partial class LoginForm: Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private async void  progressBar1_Click(object sender, EventArgs e)
        {
            progressBar1.Visible = true;  
            progressBar1.Value = 0;
            for (int i = 0; i <= 100; i += 20)
            {
                progressBar1.Value = i;
                await Task.Delay(300); 
            }
        }
    }
}
