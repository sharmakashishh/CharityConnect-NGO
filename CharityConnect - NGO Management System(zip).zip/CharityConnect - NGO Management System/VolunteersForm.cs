﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Login_Basic
{
    public partial class VolunteersForm : Form
    {
        SqlConnection cn = new SqlConnection("Data Source=KASHISH\\SQLEXPRESS01;Initial Catalog=ngo;Integrated Security=True;Encrypt=False");


        public VolunteersForm()
        {
            InitializeComponent();
            LoadVolunteers(); 

        }
        private void LoadVolunteers(string searchTerm = "")
        {
            try
            {
                if (cn.State == ConnectionState.Closed) 
                {
                    cn.Open();
                }
                string query = "SELECT * FROM Volunteers";
                SqlCommand cmd = new SqlCommand(query, cn);
                if (!string.IsNullOrWhiteSpace(searchTerm))
                {
                    query += " WHERE Name LIKE @search OR Contact LIKE @search OR Role LIKE @search";
                    cmd.CommandText = query;
                    cmd.Parameters.AddWithValue("@search", "%" + searchTerm + "%");
                }

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (cn.State == ConnectionState.Open) 
                {
                    cn.Close();
                }
            }
        }

        private bool IsVolunteerExists(string name, string contact)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=KASHISH\\SQLEXPRESS01;Initial Catalog=ngo;Integrated Security=True;Encrypt=False"))
            {
                cn.Open();
                string query = "SELECT COUNT(*) FROM Volunteers WHERE Name = @name AND Contact = @contact";
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@contact", contact);

                int count = Convert.ToInt32(cmd.ExecuteScalar());
                return count > 0; 
            }
        }

        private void ClearFields()
        {
            textBox1.Text = "";
            maskedTextBox1.Text = "";
            comboBox1.Text = "";
            SkillsTextBox.Text = "";
            AvailabilityComboBox.SelectedIndex = -1;

            
            checkBoxTeaching.Checked = false;
            checkBoxFundraising.Checked = false;
            checkBoxEventPlanning.Checked = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {


            if (textBox1.Text == "" || maskedTextBox1.Text == "" || comboBox1.Text == "")
            {
                MessageBox.Show("Please fill all fields!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (IsVolunteerExists(textBox1.Text, maskedTextBox1.Text))
            {
                MessageBox.Show("Volunteer already exists!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (cn.State == ConnectionState.Closed) 
                {
                    cn.Open();
                }
                string query = "INSERT INTO Volunteers (Name, Contact, Role, Skills, Availability, Interests) VALUES (@name, @contact, @role, @skills, @availability, @interests)";
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.Parameters.AddWithValue("@name", textBox1.Text);
                cmd.Parameters.AddWithValue("@contact", maskedTextBox1.Text);
                cmd.Parameters.AddWithValue("@role", comboBox1.Text);
                cmd.Parameters.AddWithValue("@skills", SkillsTextBox.Text);
                cmd.Parameters.AddWithValue("@availability", AvailabilityComboBox.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@interests", string.Join(", ", GetSelectedInterests()));
                cmd.ExecuteNonQuery();
                MessageBox.Show("Volunteer Added Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearFields(); 
                LoadVolunteers();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (cn.State == ConnectionState.Open) 
                {
                    cn.Close();
                }
            }
        }

            private List<string> GetSelectedInterests()
        {
            List<string> interests = new List<string>();
            if (checkBoxTeaching.Checked) interests.Add("Teaching");
            if (checkBoxFundraising.Checked) interests.Add("Fundraising");
            if (checkBoxEventPlanning.Checked) interests.Add("Event Planning");
            return interests;
        }
    

        private void button2_Click(object sender, EventArgs e)
        {

            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a volunteer to edit.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int volunteerID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["VolunteerID"].Value);

            if (textBox1.Text == "" || maskedTextBox1.Text == "" || comboBox1.Text == "")
            {
                MessageBox.Show("Please fill all fields!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (cn.State == ConnectionState.Closed)
                {
                    cn.Open();
                }

                string query = "UPDATE Volunteers SET Name = @name, Contact = @contact, Role = @role WHERE VolunteerID = @id";
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.Parameters.AddWithValue("@id", volunteerID);
                cmd.Parameters.AddWithValue("@name", textBox1.Text);
                cmd.Parameters.AddWithValue("@contact", maskedTextBox1.Text);
                cmd.Parameters.AddWithValue("@role", comboBox1.Text);
                cmd.Parameters.AddWithValue("@skills", SkillsTextBox.Text);
                cmd.Parameters.AddWithValue("@availability", AvailabilityComboBox.SelectedItem?.ToString() ?? "");
                cmd.Parameters.AddWithValue("@interests", string.Join(", ", GetSelectedInterests()));

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Volunteer Updated Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadVolunteers(); // Refresh DataGridView
                }
                else
                {
                    MessageBox.Show("No matching record found to update!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                {
                    cn.Close();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a volunteer to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int volunteerID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["VolunteerID"].Value);

            DialogResult result = MessageBox.Show("Are you sure you want to delete this volunteer?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    string query = "DELETE FROM Volunteers WHERE VolunteerID = @id";
                    SqlCommand cmd = new SqlCommand(query, cn);
                    cmd.Parameters.AddWithValue("@id", volunteerID);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Volunteer Deleted Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadVolunteers(); // Refresh DataGridView
                    }
                    else
                    {
                        MessageBox.Show("No matching record found to delete!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (cn.State == ConnectionState.Open)
                    {
                        cn.Close();
                    }
                }
            }

        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            LoadVolunteers(textBoxSearch.Text.Trim());

        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            LoadVolunteers(textBoxSearch.Text.Trim());
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Ensure row index is valid
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Populate textboxes with selected row data
                textBox1.Text = row.Cells["Name"].Value?.ToString();
                maskedTextBox1.Text = row.Cells["Contact"].Value?.ToString();
                comboBox1.Text = row.Cells["Role"].Value?.ToString();
                SkillsTextBox.Text = row.Cells["Skills"].Value?.ToString();
                AvailabilityComboBox.Text = row.Cells["Availability"].Value?.ToString();

                // Populate checkboxes for Interests
                string interests = row.Cells["Interests"].Value?.ToString() ?? "";
                checkBoxTeaching.Checked = interests.Contains("Teaching");
                checkBoxFundraising.Checked = interests.Contains("Fundraising");
                checkBoxEventPlanning.Checked = interests.Contains("Event Planning");
            }
        }
    }
}
