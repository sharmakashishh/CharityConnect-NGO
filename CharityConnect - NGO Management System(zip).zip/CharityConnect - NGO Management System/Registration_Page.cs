﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_Basic
{
    public partial class Registration_Page : Form
    {
        private readonly string connectionString = ("Data Source=KASHISH\\SQLEXPRESS01;Initial Catalog=ngo;Integrated Security=True;Encrypt=False");
        public Registration_Page()
        {
            InitializeComponent();
            comboBox1.Items.Add("Volunteer");
            comboBox1.Items.Add("Donor");
            maskedTextBox1.Mask = "+91 00000-00000";
            maskedTextBox1.PromptChar = '_';
            LoadData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string email = textBox4.Text.Trim();
            string password = textBox2.Text.Trim();
            string confirmPassword = textBox3.Text.Trim();
            string phone = maskedTextBox1.Text.Trim();
            string name = textBox1.Text.Trim();
            string membershipType = comboBox1.SelectedItem?.ToString();
            string gender = radioButton1.Checked ? "Male" : radioButton2.Checked ? "Female" : "";

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(password) ||
                string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(membershipType))
            {
                MessageBox.Show("Please fill out all required fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!IsValidEmail(email))
            {
                MessageBox.Show("Enter a valid email (e.g., user@example.com)", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!IsValidPhone(phone))
            {
                MessageBox.Show("Enter a valid Indian phone number (+91 XXXXX-XXXXX).", "Invalid Phone Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!IsStrongPassword(password))
            {
                MessageBox.Show("Password must be at least 8 characters long, include an uppercase letter, lowercase letter, a number, and a special character.", "Weak Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (password != confirmPassword)
            {
                MessageBox.Show("Passwords do not match. Please re-enter.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.BackColor = Color.LightCoral;
                textBox3.BackColor = Color.LightCoral;
                return;
            }
            else
            {
                textBox2.BackColor = Color.White;
                textBox3.BackColor = Color.White;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string hashedPassword = HashPassword(password);

                    string query = "INSERT INTO Users (Name, Gender, CreatePassword, Email, Phone, MembershipType, DateOfBirth) " +
                                   "VALUES (@Name, @Gender, @Password, @Email, @Phone, @MembershipType, @DateOfBirth)";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Gender", gender);
                        cmd.Parameters.AddWithValue("@Password", hashedPassword);
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Phone", phone);
                        cmd.Parameters.AddWithValue("@MembershipType", membershipType);
                        cmd.Parameters.AddWithValue("@DateOfBirth", dateTimePicker1.Value);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Registration Successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();

                Main m = new Main(name);
                m.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

            private bool IsValidEmail(string email)
        {
            string emailPattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            return Regex.IsMatch(email, emailPattern);
        }

        private bool IsValidPhone(string phone)
        {
            string phonePattern = @"^\+91\s\d{5}-\d{5}$";
            return Regex.IsMatch(phone, phonePattern);
        }

        private bool IsStrongPassword(string password)
        {
            return password.Length >= 8 &&
                   password.Any(char.IsUpper) &&
                   password.Any(char.IsLower) &&
                   password.Any(char.IsDigit) &&
                   password.Any(ch => !char.IsLetterOrDigit(ch));
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder sb = new StringBuilder();
                foreach (byte b in bytes)
                {
                    sb.Append(b.ToString("x2"));
                }
                return sb.ToString();
            }
        }
        private void Registration_Page_Load(object sender, EventArgs e)
        {
        }
        private void LoadData()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "SELECT ID, Name, Gender, Email, Phone, MembershipType, DateOfBirth, CreatedAt FROM Users";
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;

                    // Make DataGridView Read-Only
                    dataGridView1.ReadOnly = true;
                    dataGridView1.AllowUserToAddRows = false;

                    // Format Columns
                    dataGridView1.Columns["Name"].HeaderText = "Full Name";
                    dataGridView1.Columns["DateOfBirth"].DefaultCellStyle.Format = "dd-MM-yyyy";
                    dataGridView1.Columns["CreatedAt"].DefaultCellStyle.Format = "dd-MM-yyyy HH:mm";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            maskedTextBox1.Text = "";
            dateTimePicker1.Value = DateTime.Now;
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void label8_Click(object sender, EventArgs e)
        {
        }

        private void button5_Click(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Ensure a valid row is selected
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                textBox1.Text = row.Cells["Name"].Value?.ToString() ?? "";
                textBox4.Text = row.Cells["Email"].Value?.ToString() ?? "";
                maskedTextBox1.Text = row.Cells["Phone"].Value?.ToString() ?? "";
                comboBox1.SelectedItem = row.Cells["MembershipType"].Value?.ToString() ?? "";

                string gender = row.Cells["Gender"].Value?.ToString();
                if (gender == "Male")
                    radioButton1.Checked = true;
                else if (gender == "Female")
                    radioButton2.Checked = true;
                else
                {
                    radioButton1.Checked = false;
                    radioButton2.Checked = false;
                }

                if (DateTime.TryParse(row.Cells["DateOfBirth"].Value?.ToString(), out DateTime dob))
                {
                    dateTimePicker1.Value = dob;
                }
                else
                {
                    dateTimePicker1.Value = DateTime.Now;
                }
            }
        }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShowPassword.Checked)
            {
                textBox2.PasswordChar = '\0'; // Show password
                textBox3.PasswordChar = '\0'; // Show password
            }
            else
            {
                textBox2.PasswordChar = '*';  // Hide password
                textBox3.PasswordChar = '*';  // Hide password
            }
        }
    }
}


    






