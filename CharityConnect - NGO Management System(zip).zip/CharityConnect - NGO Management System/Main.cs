﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_Basic
{
    public partial class Main: Form
    {
        private string username;
        public Main(string username)
        {
            InitializeComponent();
            this.username = username;
            label1.Text = "Welcome," + username;
        }
        public Main()
        {
            InitializeComponent();
            label1.Text = "Welcome, Guest"; // Default message
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            VolunteersForm volunteersForm = new VolunteersForm();
            volunteersForm.Show();
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            EventsForm eventsForm = new EventsForm();
            eventsForm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DonationsForm donationsForm = new DonationsForm();
            donationsForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Logged out successfully!", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Hide();
           
        }
    }
}
