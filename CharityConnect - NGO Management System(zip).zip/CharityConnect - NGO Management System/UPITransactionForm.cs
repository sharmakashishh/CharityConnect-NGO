﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QRCoder;

namespace Login_Basic
{
    public partial class UPITransactionForm: Form
    {
        private readonly string connectionString = "Data Source=KASHISH\\SQLEXPRESS01;Initial Catalog=ngo;Integrated Security=True;Encrypt=False";

        private string donorName;
        private string phoneNumber;
        private decimal donationAmount;
        private string qrCodePath = @"C:\NGO_QRCodes";
        private string screenshotPath = @"C:\NGO_Screenshots";
        private string uploadedScreenshotPath = "";
        public UPITransactionForm(string donorName, string phoneNumber, decimal donationAmount)
        {
            InitializeComponent();

            this.donorName = donorName;
            this.phoneNumber = phoneNumber;
            this.donationAmount = donationAmount;
            

            GenerateQRCode("kashishsharma0214@okicici", donationAmount);

            lblPaymentStatus.Text = "Payment Status: Pending";
            lblPaymentStatus.ForeColor = Color.Red;
        }
        private void GenerateQRCode(string upiID, decimal amount)
        {
            string qrData = $"upi://pay?pa=kashishsharma0214@okicici&pn=NGO Donation&am={amount}&cu=INR";
            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(qrData, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);

            picQRCode.Image = qrCode.GetGraphic(5);  

            string qrFileName = SaveQRCodeToFile();
            SavePaymentConfirmation(qrFileName, null);
        }
        private void UPITransactionForm_Load(object sender, EventArgs e)
        {
            MessageBox.Show("UPI Transaction Form Loaded Successfully.");
        }

        private void btnUploadScreenshot_Click(object sender, EventArgs e)
        {

            OpenFileDialog ofd = new OpenFileDialog
            {
                Filter = "Image Files|*.jpg;*.jpeg;*.png",
                Title = "Select Payment Screenshot"
            };

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string destinationPath = $@"C:\NGO_Screenshots\{Path.GetFileName(ofd.FileName)}";

                try
                {
                    File.Copy(ofd.FileName, destinationPath, true);
                    picScreenshot.Image = Image.FromFile(destinationPath);
                    uploadedScreenshotPath = destinationPath;
                    MessageBox.Show("Screenshot uploaded successfully.", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saving screenshot: " + ex.Message, "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        private void btnConfirmPayment_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(uploadedScreenshotPath))
            {
                MessageBox.Show("Please upload a screenshot before confirming payment.",
                                "Upload Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            lblPaymentStatus.Text = "Payment Status: Confirmed";
            lblPaymentStatus.ForeColor = Color.Green;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"UPDATE Donations 
                        SET PaymentStatus = 'Confirmed', 
                            ScreenshotPath = @ScreenshotPath 
                        WHERE DonorName = @DonorName AND PhoneNumber = @PhoneNumber";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@DonorName", donorName);
                    cmd.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                    cmd.Parameters.AddWithValue("@ScreenshotPath", uploadedScreenshotPath);

                    cmd.ExecuteNonQuery();  // Update record
                }
            }

            MessageBox.Show("Payment Confirmed Successfully! Thank you for your donation.",
                            "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void SavePaymentConfirmation(string qrPath, string screenshotPath)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"INSERT INTO Donations 
                        (DonorName, PhoneNumber, Amount, PaymentMethod, DonationDate, PaymentStatus, ScreenshotPath)
                        VALUES 
                        (@DonorName, @PhoneNumber, @Amount, 'UPI', GETDATE(), @PaymentStatus, @ScreenshotPath)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@DonorName", donorName);
                    cmd.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                    cmd.Parameters.AddWithValue("@Amount", donationAmount);
                   
                    cmd.Parameters.AddWithValue("@PaymentStatus", "Confirmed");
                    cmd.Parameters.AddWithValue("@ScreenshotPath", screenshotPath ?? "NULL");
                    cmd.Parameters.AddWithValue("@QRCodePath", qrCodePath ?? "NULL");


                    cmd.ExecuteNonQuery();
                }
            }

        }

        private string SaveScreenshotToFile()
        {
            string folderPath = @"C:\NGO_Screenshots\";
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath); // Create folder if not exists
            }

            string fileName = $"Screenshot_{DateTime.Now.Ticks}.png";
            string fullPath = Path.Combine(folderPath, fileName);

            picScreenshot.Image.Save(fullPath, System.Drawing.Imaging.ImageFormat.Png);

            return fullPath;
        }

        private string SaveQRCodeToFile()
        {
            string folderPath = @"C:\NGO_QRCodes\";
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }

            string fileName = $"QRCode_{DateTime.Now.Ticks}.png";
            string fullPath = Path.Combine(folderPath, fileName);

            picQRCode.Image.Save(fullPath, System.Drawing.Imaging.ImageFormat.Png);

            return fullPath;  // Return the file path for database storage
        }




    }
}
