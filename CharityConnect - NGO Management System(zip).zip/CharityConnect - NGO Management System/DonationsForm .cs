﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Windows.Forms;

namespace Login_Basic
{
    public partial class DonationsForm : Form
    {
        private readonly string connectionString = "Data Source=KASHISH\\SQLEXPRESS01;Initial Catalog=ngo;Integrated Security=True;Encrypt=False";
        private int selectedDonationID = -1;
        public DonationsForm()
        {
            InitializeComponent();
        }
        private string GenerateTransactionID()
        {
            string prefix = "TXN";
            string uniqueID = DateTime.Now.Ticks.ToString().Substring(8);
            return prefix + uniqueID;
        }
        private void DonationsForm_Load(object sender, EventArgs e)
        { 
            dataGridView1.AutoGenerateColumns = false;
            LoadDonations();
            dataGridView1.CellDoubleClick += dataGridView1_CellDoubleClick;
        }

        private void btnDonate_Click(object sender, EventArgs e)
        {
            

            string donorName = txtDonorName.Text.Trim();
            string phoneNumber = mtxtPhone.Text.Trim();
            decimal amount = nudAmount.Value;
            string paymentMethod = cmbPaymentMethod.SelectedItem?.ToString();
            //string donationDate = dtpDonationDate.Value.ToString("dd-MM-yyyy");
            DateTime donationDate = dtpDonationDate.Value; // Ensure DateTime type


            if (string.IsNullOrEmpty(donorName) || string.IsNullOrEmpty(phoneNumber) || amount <= 0)
            {
                MessageBox.Show("Please fill in all details correctly.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrEmpty(paymentMethod))
            {
                MessageBox.Show("Please select a payment method.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"INSERT INTO Donations 
                                (DonorName, PhoneNumber, Amount, PaymentMethod, DonationDate, PaymentStatus) 
                                VALUES (@DonorName, @PhoneNumber, @Amount, @PaymentMethod, @DonationDate, 'Pending')";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@DonorName", donorName);
                    cmd.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                    cmd.Parameters.AddWithValue("@Amount", amount);
                    cmd.Parameters.AddWithValue("@PaymentMethod", paymentMethod);
                    cmd.Parameters.AddWithValue("@DonationDate", donationDate);


                    cmd.ExecuteNonQuery();
                }
            }
            LoadDonations();

            MessageBox.Show("Donation recorded successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            
            if (paymentMethod == "UPI")
            {
                try
                {
                    UPITransactionForm upiForm = new UPITransactionForm(donorName, phoneNumber, amount);
                    upiForm.ShowDialog();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error opening UPI Transaction Form: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void SaveDonationData(string paymentStatus)
            {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"INSERT INTO Donations 
                        (DonorName, PhoneNumber, Amount, PaymentMethod, DonationDate, PaymentStatus)
                        VALUES 
                        (@DonorName, @PhoneNumber, @Amount, @PaymentMethod, @DonationDate, @PaymentStatus)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@DonorName", txtDonorName.Text);
                    cmd.Parameters.AddWithValue("@PhoneNumber", mtxtPhone.Text);
                    cmd.Parameters.AddWithValue("@Amount", nudAmount.Value);

                    string selectedPaymentMethod = cmbPaymentMethod.SelectedItem != null
                        ? cmbPaymentMethod.SelectedItem.ToString()
                        : string.Empty;

                    cmd.Parameters.AddWithValue("@PaymentMethod", selectedPaymentMethod);
                    cmd.Parameters.AddWithValue("@DonationDate", dtpDonationDate.Value);
                    cmd.Parameters.AddWithValue("@PaymentStatus", paymentStatus);

                    cmd.ExecuteNonQuery(); // Ensures data gets inserted
                }
            }
            ClearFields();
            LoadDonations();
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }
        private void ClearFields()
        {
            txtDonorName.Clear();
            mtxtPhone.Clear();
            nudAmount.Value = 1;
            cmbPaymentMethod.SelectedIndex = -1;
            dtpDonationDate.Value = DateTime.Now;
        }
        


        private void LoadDonations()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT DonationID, DonorName, PhoneNumber, Amount, PaymentMethod, DonationDate, PaymentStatus FROM Donations";
                using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView1.Columns.Clear();
                    dataGridView1.DataSource = dt;
                    dataGridView1.AllowUserToAddRows = false;
                }
            }
        }

        private bool IsFormValid()
        {
            if (string.IsNullOrWhiteSpace(txtDonorName.Text) ||
                string.IsNullOrWhiteSpace(mtxtPhone.Text) ||
                nudAmount.Value <= 0 ||
                cmbPaymentMethod.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill in all fields correctly.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a donation to edit.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int donationID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["DonationID"].Value);

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"UPDATE Donations 
                         SET DonorName = @DonorName, 
                             PhoneNumber = @PhoneNumber, 
                             Amount = @Amount, 
                             PaymentMethod = @PaymentMethod, 
                             DonationDate = @DonationDate
                         WHERE DonationID = @DonationID";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@DonorName", txtDonorName.Text);
                    cmd.Parameters.AddWithValue("@PhoneNumber", mtxtPhone.Text);
                    cmd.Parameters.AddWithValue("@Amount", nudAmount.Value);
                    cmd.Parameters.AddWithValue("@PaymentMethod",
    cmbPaymentMethod.SelectedItem != null ? cmbPaymentMethod.SelectedItem.ToString() : string.Empty);

                    cmd.Parameters.AddWithValue("@DonationDate", dtpDonationDate.Value);
                    cmd.Parameters.AddWithValue("@DonationID", donationID);

                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Donation details updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ClearFields();
            LoadDonations();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a donation record to delete.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Step 2: Confirm Deletion
            DialogResult result = MessageBox.Show("Are you sure you want to delete this donation record?",
                                                  "Confirm Deletion",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Question);

            if (result == DialogResult.No)
            {
                return;  // Cancel deletion if user selects "No"
            }

            // Step 3: Retrieve the DonationID from the selected row
            int donationID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["DonationID"].Value);

            // Step 4: Delete the record from the database
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "DELETE FROM Donations WHERE DonationID = @DonationID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@DonationID", donationID);
                    cmd.ExecuteNonQuery();
                }
            }

            // Step 5: Show confirmation and reload data
            MessageBox.Show("Donation record deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            LoadDonations();  // Refresh DataGridView
        }

        private void btnOpenUPILink_Click(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Ensure a valid row is selected
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Assign values from DataGridView to form fields
                txtDonorName.Text = row.Cells["DonorName"].Value?.ToString();
                mtxtPhone.Text = row.Cells["PhoneNumber"].Value?.ToString();
                nudAmount.Value = Convert.ToDecimal(row.Cells["Amount"].Value);
                cmbPaymentMethod.SelectedItem = row.Cells["PaymentMethod"].Value?.ToString();
                dtpDonationDate.Value = Convert.ToDateTime(row.Cells["DonationDate"].Value);
            }
        }
    }

}
    

